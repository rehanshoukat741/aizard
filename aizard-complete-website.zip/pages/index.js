import { useState } from "react";

export default function Home() {
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");

  const handleGenerate = async () => {
    const res = await fetch("/api/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt: input })
    });
    const data = await res.json();
    setOutput(data.result);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 to-indigo-900 text-white p-6">
      <h1 className="text-4xl font-bold text-center mb-4">🧙‍♂️ AIZARD - AI Content Wizard</h1>
      <p className="text-center mb-6 text-lg">Write, Rewrite, Summarize & Translate with the power of AI - in English & Urdu!</p>
      <div className="max-w-2xl mx-auto bg-white text-black p-4 rounded">
        <textarea className="w-full p-2 border rounded" value={input} onChange={e => setInput(e.target.value)} placeholder="Enter your text..." />
        <button className="mt-2 bg-purple-600 text-white px-4 py-2 rounded" onClick={handleGenerate}>Generate</button>
        {output && <div className="mt-4 bg-gray-100 p-4 rounded"><strong>Result:</strong><p>{output}</p></div>}
      </div>
    </div>
  );
}
