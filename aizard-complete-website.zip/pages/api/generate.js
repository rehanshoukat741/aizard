export default async function handler(req, res) {
  const { prompt } = req.body;
  // Dummy response (replace with OpenAI API later)
  res.status(200).json({ result: `AI Output for: ${prompt}` });
}
